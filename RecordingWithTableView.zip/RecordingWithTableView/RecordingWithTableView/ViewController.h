//
//  ViewController.h
//  RecordingWithTableView
//
//  Created by Aravindakumar on 05/11/15.
//  Copyright © 2015 Aravindakumar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
@interface ViewController : UIViewController<AVAudioRecorderDelegate, AVAudioPlayerDelegate>
@property(nonatomic,strong) AVAudioRecorder *recorder;
@property(nonatomic,strong) NSMutableDictionary *recorderSettings;
@property(nonatomic,strong) NSString *recorderFilePath;
@property(nonatomic,strong) AVAudioPlayer *audioPlayer;
@property(nonatomic,strong) NSString *audioFileName;
@property (weak, nonatomic) IBOutlet UIButton *startRecording;

@property (weak, nonatomic) IBOutlet UIButton *stopRecording;

@property (weak, nonatomic) IBOutlet UIButton *playRecording;

@property (weak, nonatomic) IBOutlet UIButton *stopPLayRecording;
- (IBAction)startRecording:(id)sender;
- (IBAction)stopRecording:(id)sender;
- (IBAction)play:(id)sender;
- (IBAction)stop:(id)sender;


@end

