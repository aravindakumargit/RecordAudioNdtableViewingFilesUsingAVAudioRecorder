//
//  AppDelegate.h
//  RecordingWithTableView
//
//  Created by Aravindakumar on 05/11/15.
//  Copyright © 2015 Aravindakumar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

